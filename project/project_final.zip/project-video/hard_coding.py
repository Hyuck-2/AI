# first category
rist = ['리스트', '정통원', '정보통신', '정보 통신', '연구소',]
canteen = ['식당', '급식', '밥', '식사']
lavatory = ['화장실',]
postech = ['포항공대', '포항 공대', '포항공과대학교', '포항 공과 대학교', '포항 공과대학교', '포항', '공대',]
edu = ['기업 맞춤형 교육', '맞춤형']
ai = ['AI', '빅데이터', '아카데미']

# second category
where = ['어디', '장소', '어떻게 가']
who = ['누구']
what = ['뭐', '무엇']

# 이 부분 답 수정해주고, 위에 카테고리 좀 더 세분화할 사람 필요함 - 이게 원배랑
# 나랑 얘기하던 하드코딩 부분임
answer = [['리스트 위치', '리스트 책임자', '리스트 정의'],
          ['식당 위치', '식당과 누구라는 키워드에 대한 어떤 대답', '식당 설명'],
          ['화장실 위치', '애매한 대답', '화장실 무엇에대한 대답'],
          ['공대 위치', '공대 책임자? 총장?', '공대 설명'],
          ['기업맞춤 교육 위치' ,'기업 맞춤 교육 책임자', '기업맞춤교육 설명'],
          ['아카데미 위치', '앜데미 책임자?', '아카데미 설명']]

cat1 = [rist, canteen, lavatory, postech, edu, ai]
cat2 = []

whlie 1:
    score = [0] * len(cat1)
    # infinite listening loop should be here
    input_text = None #Giga Genie API
    for idx, category in enumerate(cat1):
        for subcat in category:
            if subcat in input_text: score[idx] += 1

    if sum(score) == 0:
        #make it say 'I didn't get your meaning, could you repeat that please?
        continue
    topic = score.index(max(score))
    if topic == 0:
        pass
    elif topic == 1:
        pass
    elif topic == 2:
        pass
    elif topic == 3:
        pass
    elif topic == 4:
        pass
    elif topic == 5:
        pass
    else:
        pass

# 뒷부분 로직은 아직 생각해봐야함
