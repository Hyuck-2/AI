import os
import socket
import time

HOST = '192.168.0.29'
PORT = 7776

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.connect((HOST, PORT))
    while 1:
        time.sleep(1)
        faces = '/'.join(os.listdir('./faces')) + 'END'
        print(faces)
        faces = faces.encode()
        sock.sendall(faces)

