import socket
import time
import subprocess
import os

HOST = 'localhost'
PORT = 7777

DIR = 'recognised'

if DIR not in os.listdir():
    subprocess.getoutput('mkdir '+ DIR)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    print('Socket Created!')

    sock.bind((HOST, PORT))
    print('Socket Bound!')

    sock.listen(10)
    print('Socket Listening!')

    conn, addr = sock.accept()
    print(addr)
    print('Socket Connection from ' + addr[0] + ' Accepted!')
    flag = [0] * 7

    recognise_list = ['Hyuck', 'Jaeyoon', 'Joonyoung', 'Gayoung', 'Sunkyung', 'Jinju', 'Wonbae']

    while 1:
        time.sleep(1)
        data = conn.recv(1024).decode()
        names = data[:data.find('END')]
        names = names.split('/')
        print(names)
        for name in names:
            if name in recognise_list:
                flag[recognise_list.index(name)] += 1
        for name in list(set(recognise_list) - set(names)):
            flag[recognise_list.index(name)] = 0

        for idx, person in enumerate(flag):
            #if a person had been recognised for more than 3 seconds
            if person >= 3:
                with open(DIR + '/' + recognise_list[idx], 'w+') as f:
                    f.write('')
                flag = [0] * 7
